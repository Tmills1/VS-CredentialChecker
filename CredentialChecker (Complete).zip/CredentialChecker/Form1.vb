﻿Public Class Form1

    ' Declare the 1D array to store user information
    Dim userArray(,) As String = {{"user1", "password1"}, {"user2", "password2"}, {"user3", "password3"}, {"tyler1", "mills2"}, {"aaliyah", "lockett"}, {"i8u", "icu"}}

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click

        ' Get the user input from the text boxes
        Dim username As String = TextBox1.Text
        Dim password As String = TextBox2.Text

        ' Check if the username and password match the userArray
        Dim isValidUser As Boolean = False
        For i = 0 To userArray.GetLength(0) - 1
            If userArray(i, 0) = username AndAlso userArray(i, 1) = password Then
                isValidUser = True
                Exit For
            End If
        Next

        ' Use a switch statement to handle the user validation
        Select Case isValidUser
            Case True
                MsgBox("Login successful!")
            Case False
                MsgBox("Invalid username or password.")
        End Select

        ' Clear the text boxes
        TextBox1.Clear()
        TextBox2.Clear()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click

        ' Write the user information to a file
        Dim filePath As String = "users.txt"
        Dim fileWriter As New System.IO.StreamWriter(filePath)

        For i = 0 To userArray.GetLength(0) - 1
            fileWriter.WriteLine(userArray(i, 0) & "," & userArray(i, 1))
        Next

        fileWriter.Close()

        ' Output the user information using message boxes
        Dim output As String = ""
        For i = 0 To userArray.GetLength(0) - 1
            output += "Username: " & userArray(i, 0) & System.Environment.NewLine & "Password: " & userArray(i, 1) & vbNewLine & vbNewLine
        Next

        MsgBox(output)

    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub
End Class
